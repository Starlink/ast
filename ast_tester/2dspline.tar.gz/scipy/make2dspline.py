#!/bin/python3

#  Use SciPy functions to fit a pair of interpolating bivariate splines to
#  a pair of surfaces, each  defined via an analytical function. Then dump
#  the knots and coefficients defining the fitted splines to standard output
#  (these should be redirected to a file called 2dspline_c.dat that will be
#  read in by the C SplineMap test routine "testspline_c.c").
#
#  The analytical functions used are the same as those used by
#  make2dspline.f (the program that generates the spline knots and coeffs
#  for the Fortran SPlineMap test program).
#
#  If "dump" is set False, then the data defining the splines is not written
#  out. Instead, the splines are evaluated at a set of standard
#  positioins and the resulting spline values are written out. These
#  should be used as the "expected values" in testsplinemap.c.

import numpy as np
from scipy.interpolate import RectBivariateSpline

xval = [ 0.0, 12.5, 12.0, 1.0, 15.0, 1.0, 95.0, 149.5, 151.2, 77.77 ]
yval = [ -1.0, 8.8, 8.0, 1.0, 15.0, 76.0, 100.0, 99.8, 82.3, 54.3 ]

nx = 150
ny = 100
k = 4
a = 4.0
b = 0.2
c = 3.0
dump = True
#dump = False

xs = np.linspace( 1, nx, nx )
ys = np.linspace( 1, ny, ny )

fcx = np.zeros((nx,ny))
fcy = np.zeros((nx,ny))
for j in range(ny):
   y = ys[ j ]
   for i in range(nx):
      x = xs[ i ]
      fcx[i][j]  = x + a*np.sin(b*x) * np.cos(b*y)
      fcy[i][j]  = y + c*np.cos(b*x) * np.sin(b*y)


splinex = RectBivariateSpline( xs, ys, fcx, s=0 )
if dump:
   (tx,ty) = splinex.get_knots()

   if len(tx) != nx+ k:
      print("BANG x!!!!")
   if len(ty) != ny+ k:
      print("BANG y!!!!")

   for t in tx:
     print(t)
   for t in ty:
     print(t)
   ar = splinex.get_coeffs()
   if len(ar) != nx*ny:
      print("BANG coeff!!!!")

   for a in ar:
      print( a )

spliney = RectBivariateSpline( xs, ys, fcy, s=0 )
if dump:
   ar = spliney.get_coeffs()
   for a in ar:
      print( a )


if not dump:
   for (x,y) in zip( xval, yval ):
      u = splinex.ev( x, y )
      v = spliney.ev( x, y )
      print( u, v )
